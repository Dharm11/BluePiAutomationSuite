package com.azentio.loginpage.testcases;

import java.lang.reflect.Method;
import java.util.HashMap;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.azentio.generic.test.Base;
import com.azentio.generic.test.Global;
import com.azentio.generic.test.TestData;
import com.azentio.utility.test.Helper;

public class LoginTest extends Base {
	HashMap<String, String> inputDataMap;
	// = new HashMap<String, String>();
	LoginPage login;
	SoftAssert soft;

	@Test(dataProvider = "get-test-data-method")
	public void verifyLogin(HashMap<String, String> testData, Method testMethod) {
		inputDataMap = new HashMap<String, String>();
		soft = getSoftAssert(testMethod.getName().toString());
		inputDataMap = TestData.extractTestDataintoMap(testData.get("INPUT_DATA"));
		login = new LoginPage(getDriver());
		login.loginToApp(inputDataMap.get("username"), inputDataMap.get("password"), soft);
		Helper.validateEquals(inputDataMap.get("username"), "gayatri28121990@gmail.com", soft);
		login.clickLoginButton();
		soft.assertAll();

	}

	@Test(dataProvider = "get-test-data-method")
	public void verifyLogin_Test(HashMap<String, String> testData, Method testMethod) {
		soft = getSoftAssert(testMethod.getName().toString());
		inputDataMap = new HashMap<String, String>();
		inputDataMap = TestData.extractTestDataintoMap(testData.get("INPUT_DATA"));
		login = new LoginPage(getDriver());
		login.loginToApp(inputDataMap.get("username"), inputDataMap.get("password"), soft);
		login.clickLoginButton();
		soft.assertAll();

	}

//	@Test(dataProvider = "get-test-data-method")
//	public void test2(HashMap<String, String> testData, Method testMethod) {
//		System.out.println("asjdha sakjd ad");
//		inputDataMap = TestData.extractTestDataintoMap(testData.get("INPUT_DATA"));
//		login = new LoginPage(getDriver());
//		login.loginToApp(inputDataMap.get("username"), inputDataMap.get("password"), soft);
//	}

}
