package com.azentio.loginpage.testcases;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.asserts.SoftAssert;
import com.azentio.generic.test.Base;
import com.azentio.generic.test.Global;
import com.azentio.generic.test.Reporting;
import com.azentio.generic.test.TestData;
import com.azentio.generic.test.UserActions;

public class LoginPage extends Base{
	
	@FindBy(id = "email")
	WebElement userName;

	@FindBy(id = "pass")
	WebElement password;

	@FindBy(xpath = "//button[text()='Log In']")
	WebElement btnLogin;
		
	public LoginPage(WebDriver driver) {
		PageFactory.initElements((WebDriver) driver, this);
	}


	public void loginToApp(String strUserName , String strPassword, SoftAssert soft) {
		try {
			LoginPage.invokeAPP();
			UserActions.enterText(userName, "username", strUserName, soft);  //webelement  label str
			UserActions.enterText(password, "password", strPassword, soft);
			
		 }
		  catch(Exception e) {
			Reporting.writeSparkLogs("FAIL", "Not able to login and exception in *loginToApp* method");
			soft.fail();
		 }
		
	}
	
	public static void invokeAPP() {
		try {
			String appURl = TestData.readEnvDetails(Global.environmentName);
			getDriver().get(appURl);
			//driver.get(appURl);
		}
		  catch(Exception e) {
				Reporting.writeSparkLogs("FAIL", "Unable to read environment details from *MultipleEnv_data* File against " +Global.environmentName);
		}
		
	}
	
	public void clickLoginButton() {
		try {
			UserActions.clickElement(btnLogin, "login");
		 }
		  catch(Exception e) {
			Reporting.writeSparkLogs("FAIL", "Not able to click on login button and exception in *clickLoginButton* method");
		 }
		
	}


}
