package com.azentio.createform.testcases;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class CreateForm {
	
	@FindBy(xpath = "//a[text()=\"Create New Account\"]")
	WebElement clickCreateButton;
	
	@FindBy(xpath="//input[@name=\"firstname\"]")
	WebElement enterUname;

	@FindBy(xpath="//input[@name=\"lastname\"]")
	WebElement enterLastname;
	
	@FindBy(xpath="//input[@name=\"reg_email__\"]")
	WebElement enterMail;
	
	@FindBy(id="password_step_input")
	WebElement enterPwd;

}
 