package com.azentio.utility.test;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.asserts.SoftAssert;

import com.azentio.generic.test.Reporting;

public class Helper {
	public static String getCurrentDateTime() {
		DateFormat customFormat = new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss");
		Date currentDate = new Date();
		return customFormat.format(currentDate);
	}

	public static String captureScreenshot(ThreadLocal<WebDriver> driver) {
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		String screenshotpath = System.getProperty("user.dir") + "/Screenshots/Azentio+" + getCurrentDateTime()
				+ ".png";
		try {
			FileUtils.copyFile(src, new File(screenshotpath));

			System.out.println("Screenshot Captured");

		} catch (IOException e) {
			System.out.println("Unable to capsture screenshot " + e.getMessage());
		}
		return screenshotpath;
	}

	// To execute only failed test cases

	public static String IRetryAnalyzer() {
		return null;

	}

	public static void validateEquals(String actual, String expected, SoftAssert soft) {
		try {
			if (actual.contentEquals(expected)) {
				Reporting.writeSparkLogs("PASS",
						"Actual and expected are matched. Actual : " + actual + " Expected : " + expected);
			} else {
				Reporting.writeSparkLogs("FAIL",
						"Actual and expected Not matched. Actual : " + actual + " Expected : " + expected);
			}

			soft.assertEquals(actual, expected,
					"Actual and expected are NOT matched. Actual : " + actual + " Expected : " + expected);
		} catch (Exception e) {
			soft.assertEquals("FAIL",
					"Actual and expected are NOT matched. Actual : " + actual + " Expected : " + expected);
			soft.assertEquals(actual, expected,
					"Actual and expected are NOT matched. Actual : " + actual + " Expected : " + expected);
		}
	}

}
