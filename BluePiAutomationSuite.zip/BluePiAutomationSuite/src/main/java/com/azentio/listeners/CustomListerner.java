package com.azentio.listeners;

import org.testng.ITestListener;
import org.testng.ITestResult;

import com.azentio.generic.test.Base;
import com.azentio.utility.test.Helper;

public class CustomListerner implements ITestListener {

	@Override
	public void onTestStart(ITestResult result) {

	}

	public void onTestSuccess(ITestResult result) {

	}

	
	public void onTestFailure(ITestResult result) {
		System.out.println("Failed Test");
		//Helper.captureScreenshot(driver);

	}

	public void onTestSkipped(ITestResult result) {

	}
}
