package com.azentio.generic.test;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.SoftAssert;

public class UserActions extends Base {
	//static WebDriver driver;
	static long defaultWaitPeriod = 2000;

	public static void clickElement(WebElement ele, String label) {
		try {
			ele.click();
			Reporting.writeSparkLogs("PASS", "Sucessfully click on " + label);
		} catch (Exception e) {
			Reporting.writeSparkLogs("FAIL", "Sucessfully click on " + label + " -- Exception ---> " + e.getMessage());

		}

	}

//	public static void waitTillElementNotVisible(By by) {
//		try {
//
//			WebDriverWait wait = new WebDriverWait(driver, defaultWaitPeriod * 2);
//			wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
//			Thread.sleep(defaultWaitPeriod);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}

//	// Element is Present or NOT
//	public static boolean isElementPresent(WebElement ele) {
//		try {
//			Global.element = driver.findElement((By) ele);
//			return ele.isDisplayed();
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			return false;
//		}
//	}
//
////    // Get String To verify
//	public static String Chkforthestring(WebElement ele) {
//		try {
//			Global.element = driver.findElement((By) ele);
//			String toverify = ele.getText();
//			return toverify;
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			return null;
//		}
//	}
//
//// Check Or Uncheck the value of Checkbox
//	public static void checkUncheck(By by, boolean check) {
//		Global.element = driver.findElement(by);
//		boolean select = Global.element.isSelected();
//
//		if (check != select && !select == check)
//			Global.element.click();
//	}
//
//	// Verify checkbox is selected or not
//	public static boolean ischecked(WebElement ele) {
//		ele = driver.findElement((By) ele);
//		return ele.isSelected();
//	}

	public static void enterText(WebElement ele, String label, String strValue, SoftAssert soft) {
		try {
			ele.sendKeys(strValue);
			Reporting.writeSparkLogs("PASS", "Sucessfully enter  " + strValue + " in " + label);
			//soft.fail( "Sucessfully enter  " + strValue + " in " + label);
		} catch (Exception e) {
			Reporting.writeSparkLogs("FAIL", "Failed to enter  " + strValue + " in " + label);
			soft.fail("Failed to enter  " + strValue + " in " + label);
		}

	}
	
//
//	public static void rightClick(By by) {
//		WebDriverWait wait = new WebDriverWait(driver, defaultWaitPeriod * 2);
//		wait.until(ExpectedConditions.elementToBeClickable(by));
//		Actions actions = new Actions(driver);
//		actions.contextClick(driver.findElement(by)).perform();
//	}
//
//	public static void click(By by) {
//		WebDriverWait wait = new WebDriverWait(driver, defaultWaitPeriod * 2);
//		wait.until(ExpectedConditions.elementToBeClickable(by));
//		driver.findElement(by).click();
//	}
//
//	public static void type(By by, String inputText) {
//		WebDriverWait wait = new WebDriverWait(driver, defaultWaitPeriod);
//		wait.until(ExpectedConditions.visibilityOfElementLocated(by));
//		driver.findElement(by).sendKeys(Keys.CONTROL + "a" + Keys.BACK_SPACE);
//		try {
//			Thread.sleep(1000);
//		} catch (InterruptedException e) {
//			e.printStackTrace();
//		}
//		driver.findElement(by).sendKeys(inputText);
//	}
//
//	public static void typeKeys(By by, Keys tab) {
//		WebDriverWait wait = new WebDriverWait(driver, defaultWaitPeriod);
//		wait.until(ExpectedConditions.visibilityOfElementLocated(by));
//		driver.findElement(by).sendKeys(tab);
//	}
//
//	public static void mouseOver(By by) {
//		WebDriverWait wait = new WebDriverWait(driver, defaultWaitPeriod);
//		wait.until(ExpectedConditions.visibilityOfElementLocated(by));
//		Actions actions = new Actions(driver);
//		WebElement actionName = driver.findElement(by);
//		actions.moveToElement(actionName).perform();
//	}
//
//	public static boolean isStringOnlyAlphabet(String str) {
//		String stringWithoutSpaces = str.replaceAll("\\s+", "");
//		return ((str != null) && (!str.equals("")) && (str.matches("^[a-zA-Z]*$")));
//	}
//
//	public static boolean isClickable(WebElement webe) {
//		try {
//			WebDriverWait wait = new WebDriverWait(driver, 2);
//			wait.until(ExpectedConditions.elementToBeClickable(webe));
//			return true;
//		} catch (Exception e) {
//			return false;
//		}
//	}
//
//	public static void waitTillElementVisible(By by) {
//		try {
//			WebDriverWait wait = new WebDriverWait(driver, defaultWaitPeriod * 2);
//			wait.until(ExpectedConditions.visibilityOfElementLocated(by));
//			Thread.sleep(defaultWaitPeriod);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//
//	public static void waitTillElementVisible(WebElement element) {
//		try {
//			WebDriverWait wait = new WebDriverWait(driver, defaultWaitPeriod * 2);
//			wait.until(ExpectedConditions.visibilityOf(element));
//			Thread.sleep(defaultWaitPeriod);
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
//
//	public static void switchToWindow() {
//		String parent = driver.getWindowHandle();
//		Set<String> s = driver.getWindowHandles();
//		Iterator<String> I1 = s.iterator();
//		while (I1.hasNext()) {
//
//			String child_window = I1.next();
//			if (!parent.equals(child_window)) {
//				driver.switchTo().window(child_window);
//				System.out.println(driver.switchTo().window(child_window).getTitle());
//				// driver.close();
//			}
//		}
//		// driver.switchTo().window(parent);
//	}
//
//	public static boolean isEnabled(By by) {
//
//		return driver.findElement(by).isEnabled();
//	}
//
//	public static void mouseMoveToElement(WebElement element) {
//
//		Actions actions = new Actions(driver);
//		String mouseOverScript = "if(document.createEvent){var evObj = document.createEvent('MouseEvents');evObj.initEvent('mouseover',true, false); arguments[0].dispatchEvent(evObj);} else if(document.createEventObject) { arguments[0].fireEvent('onmouseover');}";
//		actions.moveToElement(element).perform();
//
//	}
//
//	public static void scrollToElement(WebElement element, int offset) {
//
//		if (offset != 0)
//			((JavascriptExecutor) driver)
//					.executeScript("arguments[0].scrollIntoView();window.scrollBy(0, " + offset + ");", element);
//		else
//			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView();", element);
//	}
//
//	public static WebElement getElement(By locator) {
//		return driver.findElement(locator);
//	}
//   
//
//	public static void selectDropDownValue(By locator, String type, String value) {
//		Select select = new Select(getElement(locator));
//		switch (type) {
//		case "index":
//			select.selectByIndex(Integer.parseInt(value));
//			break;
//
//		case "value":
//			select.selectByValue(value);
//			break;
//
//		case "visibletext":
//			select.deselectByVisibleText(value);
//			break;
//
//		default:
//			System.out.println("Please pass the correct selection criteria: .....");
//			break;
//		}
//	}
}
