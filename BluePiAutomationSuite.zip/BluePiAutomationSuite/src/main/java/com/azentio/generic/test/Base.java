package com.azentio.generic.test;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.ITestContext;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Listeners;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.azentio.listeners.CustomListerner;
import com.azentio.utility.test.Helper;

import io.github.bonigarcia.wdm.WebDriverManager;

//@Listeners(CustomListerner.class)
public class Base {

//	public WebDriver driver;
	private static Map<String, SoftAssert> softAsserts = new ConcurrentHashMap<String, SoftAssert>();
	public static ThreadLocal<WebDriver> driver = new ThreadLocal<WebDriver>();

	@BeforeSuite
	public void setUpSuite(ITestContext context) {
		String strEnv = context.getCurrentXmlTest().getParameter("environment");
		Global.environmentName = strEnv;
		Reporting.sparkReport();
	}

	@AfterMethod
	public void teardownSuite() {
		Global.reports.flush();
	}

	
	@BeforeMethod
	public void setUpMethod(ITestContext context, Method testMethod) {
		String strMethodName = testMethod.getName();
		String strBrowser = context.getCurrentXmlTest().getParameter("browser");
		driver = createDriverInstance(strBrowser);
		Global.logger = Global.reports.createTest(strMethodName);
		SoftAssert softAssert = new SoftAssert();
		softAsserts.put(testMethod.getName(), softAssert);
	}

	public static WebDriver getDriver() {

		return driver.get();

	}

	
	public static ThreadLocal<WebDriver> createDriverInstance(String strBrowser) {
		if ((strBrowser).equals("CHROME")) {
			WebDriverManager.chromedriver().setup();
			driver.set(new ChromeDriver());
		}
		
		 else if ((strBrowser).equals("FIREFOX")) {
			WebDriverManager.firefoxdriver().setup();
			driver.set(new FirefoxDriver());
			
		} else if (strBrowser.equals("EDGE")) {
			WebDriverManager.edgedriver().setup();
			driver.set(new EdgeDriver());
		}
		return driver;
	}

	@DataProvider(name = "get-test-data-method", parallel = true)
	public synchronized Object[][] getTestDataMethod(Method testMethod) {
		String strMethodName = testMethod.getName(); // takes the test method name
		String strClassName = this.getClass().getSimpleName(); // class name
		String strdataFileName = strClassName + "_data.xlsx"; // map class name with _data
		Map objDataMap = TestData.readTestData(strdataFileName, strMethodName);
		Object[][] result = new Object[1][];
		result[0] = new Object[] { objDataMap };
		return result;

	}

	@AfterMethod
	public void tearDownMethod(ITestResult result) throws IOException {
		try {
			Reporter.log("Test is about to end", true);

			if (result.getStatus() == ITestResult.FAILURE) {
				Helper.captureScreenshot(driver);
				Global.logger.fail("Test Failed",
						MediaEntityBuilder.createScreenCaptureFromPath(Helper.captureScreenshot(driver)).build());
//		} else if (result.getStatus() == ITestResult.SUCCESS) {
//			Global.logger.pass("Test Passed",
//					MediaEntityBuilder.createScreenCaptureFromPath(Helper.captureScreenshot(driver)).build());
//		} else if (result.getStatus() == ITestResult.SKIP) {
//			Global.logger.skip("Test Skipped",
//					MediaEntityBuilder.createScreenCaptureFromPath(Helper.captureScreenshot(driver)).build());
//		}
			}
		} catch (Exception e) {

		}

		getDriver().quit();
		Reporter.log("Test Completed >> Report Generated", true);

	}

	public SoftAssert getSoftAssert(String methodName) {
		return softAsserts.get(methodName);
	}

}
