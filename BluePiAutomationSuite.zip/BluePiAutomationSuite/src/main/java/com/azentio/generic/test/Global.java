package com.azentio.generic.test;

import java.io.File;
import java.util.Properties;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.asserts.SoftAssert;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.azentio.utility.test.Helper;

public class Global {
	//Reporting variables
		public static ExtentSparkReporter spark = new ExtentSparkReporter(new File(
				System.getProperty("user.dir") + "/Report/DemoReport+" + Helper.getCurrentDateTime() + ".html"));
		public static ExtentReports reports = new ExtentReports();
		public static ExtentTest logger;
		public static String seleniumSpark = System.getProperty("user.dir")+"\\TestResultLogs\\Results\\sparkReport.html";
		public static String appURL="https://www.facebook.com/";
		public static Actions actAll;
		public static JavascriptExecutor jse;
	    public static WebElement element;
	    public static Properties properties;
	    public static int defaultWaitPeriod;
	    public static int slowThreadSleep;
	    public static String USERNAME;
	    public static String environmentName;
	    		

}
