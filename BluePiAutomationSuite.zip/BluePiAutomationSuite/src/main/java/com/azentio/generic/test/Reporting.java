package com.azentio.generic.test;

import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class Reporting {

	
//	public static void createSparkReport() {
//		try {			
//			Global.reports = new ExtentReports();
//			Global.spark = new ExtentSparkReporter(Global.seleniumSpark);
//			Global.reports.attachReporter(Global.spark);			
//		}
//		catch(Exception e) {
//			System.out.println("Error in report creation");
//		}
//		
//	}
	
	
	public static void writeSparkLogs(String strPASSFAIL , String strDesc) {
		if(strPASSFAIL.contentEquals("PASS")){
		Global.logger.log(Status.PASS, strDesc);	
	}
		else if(strPASSFAIL.contentEquals("FAIL")) {
			Global.logger.log(Status.FAIL, strDesc);
		}		
	}
	
	
	public static void sparkReport() {
		Global.spark.config().setTheme(Theme.DARK);
		Global.spark.config().setDocumentTitle("MyReport");
		Global.reports.attachReporter(Global.spark);		
		
	}	

}
