//package com.azentio.generic.test;
//
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.edge.EdgeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
//
//import io.github.bonigarcia.wdm.WebDriverManager;
//
//public class InitDriver extends Base {
//	
//
//	//static WebDriver driver;
//	
//	public static WebDriver getDriver() {
//		
//		return driver;
//		
//	}
//	 	
//	public static WebDriver createDriverInstance(String strBrowser) {
//		if(((Object) strBrowser).equals("CHROME")) {
//			WebDriverManager.chromedriver().setup();
//			((WebDriver) driver).get(strBrowser);
//			//driver = new ChromeDriver();
//		}
//		else if(((Object) strBrowser).equals("FIREFOX")){
//			WebDriverManager.firefoxdriver().setup();
//			driver.get(strBrowser);
//			//driver =  new FirefoxDriver();
//		}
//		else if(strBrowser.equals("EDGE")){
//			WebDriverManager.edgedriver().setup();
//			driver.get(strBrowser);
//			//driver =  new EdgeDriver();
//		}
//		
//		return driver;
//		
//	  
//	}
//	
//	
//
//}
